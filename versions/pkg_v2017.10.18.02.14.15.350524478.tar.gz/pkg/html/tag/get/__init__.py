#!/usr/bin/env python
# -*- coding: UTF-8 -*-

"""Module about get tags in html"""
