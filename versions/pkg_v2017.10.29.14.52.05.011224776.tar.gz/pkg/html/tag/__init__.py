#!/usr/bin/env python
# -*- coding: UTF-8 -*-

"""
Module about tags in HTML.
"""

from . import get
from . import regex
