#!/usr/bin/env python
# -*- coding: UTF-8 -*-

"""
Test module about get tags in HTML.
"""
