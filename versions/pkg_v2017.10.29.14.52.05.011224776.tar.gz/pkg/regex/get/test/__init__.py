#!/usr/bin/env python
# -*- coding: UTF-8 -*-

"""
Test the module which get a compiled list of RegEx.
"""
