#!/usr/bin/env python
# -*- coding: UTF-8 -*-

"""
Module which get a list of RegEx patters and return the compiled list.
"""

from . import compiled_list
