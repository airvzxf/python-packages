#!/usr/bin/env python
# -*- coding: UTF-8 -*-

"""
Module which handle the RegEx.
"""

from . import get
