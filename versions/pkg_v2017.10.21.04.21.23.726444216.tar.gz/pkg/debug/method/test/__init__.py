#!/usr/bin/env python
# -*- coding: UTF-8 -*-

"""Test module about show methods usages in debug mode"""
