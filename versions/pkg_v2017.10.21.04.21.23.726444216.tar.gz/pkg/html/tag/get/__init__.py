#!/usr/bin/env python
# -*- coding: UTF-8 -*-

"""Module about get tags in html"""

from . import all_from
from . import all_properties
from . import only_open
from . import raw_content_from
