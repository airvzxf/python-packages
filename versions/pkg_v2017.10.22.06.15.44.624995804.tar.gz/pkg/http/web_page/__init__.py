#!/usr/bin/env python
# -*- coding: UTF-8 -*-

"""Module: Handle the web page from protocol."""

from . import get
