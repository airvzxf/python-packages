#!/usr/bin/env python
# -*- coding: UTF-8 -*-

"""Test module about handle the web page from http protocol."""
