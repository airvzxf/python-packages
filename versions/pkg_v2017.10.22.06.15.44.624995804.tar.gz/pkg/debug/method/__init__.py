#!/usr/bin/env python
# -*- coding: UTF-8 -*-

"""Methods in objects."""

from . import show_available
