#!/usr/bin/env python
# -*- coding: UTF-8 -*-

"""Module about regEx tags patterns in HTML"""
